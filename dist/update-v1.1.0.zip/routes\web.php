<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{
    ListingController, BidController, PaymentController, WalletController,
    StoreController, CartController, CheckoutController, OrderController, DashboardController
};
use App\Http\Controllers\Admin\{
    ListingController as AdminListingController, 
    ShippingMethodController, 
    OrderController as AdminOrderController,
    AdminController,
    SettingsController,
    FinancialReportController,
    CategoryController
};

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/', [ListingController::class, 'index'])->name('home');
Route::get('/categories', [\App\Http\Controllers\CategoryPageController::class, 'index'])->name('categories.index');

// Authentication Routes - فقط برای کاربران لاگین نشده
Route::middleware('guest')->group(function () {
    Route::get('/login', function () { return view('auth.login'); })->name('login');
    Route::get('/register', function () { return view('auth.register'); })->name('register');

    // ورود با رمز عبور
    Route::post('/login', function (\Illuminate\Http\Request $request) {
        $login     = $request->input('login');
        $fieldType = filter_var($login, FILTER_VALIDATE_EMAIL) ? 'email' : 'phone';
        $credentials = [$fieldType => $login, 'password' => $request->input('password')];

        if (auth()->attempt($credentials, $request->filled('remember'))) {
            $request->session()->regenerate();
            return redirect()->intended('/dashboard');
        }

        return back()->withErrors(['login' => 'اطلاعات ورود نادرست است.'])->withInput($request->only('login'));
    });

    // ثبت‌نام با تایید OTP
    Route::post('/register', [\App\Http\Controllers\Auth\OtpController::class, 'completeRegister']);

    // ─── OTP Routes ───────────────────────────────────────────────────
    Route::get('/login/otp', [\App\Http\Controllers\Auth\OtpController::class, 'loginForm'])->name('otp.login');
    Route::post('/login/otp/send', [\App\Http\Controllers\Auth\OtpController::class, 'sendLoginOtp'])->name('otp.login.send');
    Route::get('/login/otp/verify', [\App\Http\Controllers\Auth\OtpController::class, 'verifyLoginForm'])->name('otp.login.verify.form');
    Route::post('/login/otp/verify', [\App\Http\Controllers\Auth\OtpController::class, 'verifyLogin'])->name('otp.login.verify');

    // فراموشی رمز عبور
    Route::get('/forgot-password', [\App\Http\Controllers\Auth\ForgotPasswordController::class, 'showForm'])->name('password.request');
    Route::get('/password/reset', function() { return view('auth.forgot-password'); })->name('password.forgot');
});

// ارسال OTP در ثبت‌نام (AJAX) - بدون middleware guest چون ممکنه AJAX باشه
Route::post('/register/otp/send', [\App\Http\Controllers\Auth\OtpController::class, 'sendRegisterOtp'])->name('otp.register.send');
Route::post('/otp/resend', [\App\Http\Controllers\Auth\OtpController::class, 'resend'])->name('otp.resend');
// ─────────────────────────────────────────────────────────────────

Route::post('/logout', function () { auth()->logout(); return redirect('/'); })->name('logout');

// Password Reset Routes
Route::get('/password/request', [\App\Http\Controllers\Auth\PasswordResetOtpController::class, 'showForm'])->name('password.request');
Route::post('/password/otp/send', [\App\Http\Controllers\Auth\PasswordResetOtpController::class, 'sendOtp'])->name('password.otp.send');
Route::get('/password/otp/verify', [\App\Http\Controllers\Auth\PasswordResetOtpController::class, 'showVerifyForm'])->name('password.otp.verify.form');
Route::post('/password/otp/verify', [\App\Http\Controllers\Auth\PasswordResetOtpController::class, 'verifyOtp'])->name('password.otp.verify');
Route::post('/password/otp/reset', [\App\Http\Controllers\Auth\PasswordResetOtpController::class, 'resetPassword'])->name('password.otp.reset');

// Legacy email reset (نگه می‌داریم برای سازگاری)
Route::get('/password/reset/{token}', [\App\Http\Controllers\Auth\ResetPasswordController::class, 'showResetForm'])->name('password.reset');
Route::post('/password/reset', [\App\Http\Controllers\Auth\ResetPasswordController::class, 'reset'])->name('password.update');

// API Routes
Route::get('/api/listings/search', [\App\Http\Controllers\Api\ListingController::class, 'search']);
Route::get('/api/categories/structure', [\App\Http\Controllers\Api\CategoryController::class, 'getStructure']);
Route::get('/api/categories/{category}/attributes', [\App\Http\Controllers\Api\CategoryController::class, 'getAttributes']);
Route::get('/api/categories/{category}/path', [\App\Http\Controllers\Api\CategoryController::class, 'getPath']);

// Listings
Route::get('/listings', [ListingController::class, 'index'])->name('listings.index');

// Comments (Public - requires auth)
Route::middleware('auth')->group(function () {
    Route::post('/listings/{listing}/comments', [\App\Http\Controllers\ListingCommentController::class, 'store'])->name('listings.comments.store');
});

Route::middleware('auth')->group(function () {
    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard/chart-data', [DashboardController::class, 'sellerChartData'])->name('dashboard.chart-data');

    // Profile
    Route::get('/profile', [\App\Http\Controllers\ProfileController::class, 'edit'])->name('profile.edit');
    Route::put('/profile', [\App\Http\Controllers\ProfileController::class, 'update'])->name('profile.update');
    
    // Seller Request
    Route::get('/become-seller', [\App\Http\Controllers\SellerRequestController::class, 'create'])->name('seller-request.create');
    Route::post('/become-seller', [\App\Http\Controllers\SellerRequestController::class, 'store'])->name('seller-request.store');
    Route::get('/seller-request/status', [\App\Http\Controllers\SellerRequestController::class, 'status'])->name('seller-request.status');
    
    // Listings (Authenticated) - IMPORTANT: /listings/create must come BEFORE /listings/{listing}
    Route::get('/my-listings', [ListingController::class, 'myListings'])->name('my-listings');
    Route::get('/my-bids', [ListingController::class, 'myBids'])->name('my-bids');
    Route::get('/listings/create', [ListingController::class, 'create'])->name('listings.create');
    Route::get('/listings/{listing}/edit', [ListingController::class, 'edit'])->name('listings.edit');
    
    Route::post('/listings', [ListingController::class, 'store'])->name('listings.store');
    Route::put('/listings/{listing}', [ListingController::class, 'update'])->name('listings.update');
    Route::post('/listings/{listing}/participate', [ListingController::class, 'participate'])->name('listings.participate');
    Route::post('/listings/{listing}/finalize', [ListingController::class, 'finalize'])->name('listings.finalize');
});

// Listings show route - MUST come AFTER /listings/create to avoid conflicts
Route::get('/listings/{listing}', [ListingController::class, 'show'])->name('listings.show');

Route::middleware('auth')->group(function () {
    // Bidding
    Route::post('/bids', [BidController::class, 'store'])
        ->name('bids.store')
        ->middleware('throttle:bids');
    
    // Payment
    Route::post('/payment/complete', [PaymentController::class, 'complete'])->name('payment.complete');
    
    // Wallet
    Route::get('/wallet', [WalletController::class, 'show'])->name('wallet.show');
    Route::post('/wallet/add-funds', [WalletController::class, 'addFunds'])->name('wallet.add-funds');
    Route::post('/wallet/withdraw', [WalletController::class, 'withdraw'])->name('wallet.withdraw');
    Route::get('/wallet/export', [WalletController::class, 'export'])->name('wallet.export');
    Route::any('/wallet/payment/callback', [WalletController::class, 'paymentCallback'])->name('wallet.payment.callback');

    
    // Store
    Route::get('/store/{username}', [StoreController::class, 'show'])->name('stores.show');
    Route::get('/stores/edit', [StoreController::class, 'edit'])->name('stores.edit');
    Route::put('/stores', [StoreController::class, 'update'])->name('stores.update');
    Route::post('/stores/upload-banner', [StoreController::class, 'uploadBanner'])->name('stores.upload-banner');
    Route::post('/stores/upload-logo', [StoreController::class, 'uploadLogo'])->name('stores.upload-logo');
    
    // Orders
    Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/export', [OrderController::class, 'export'])->name('orders.export');
    Route::get('/orders/{order}', [OrderController::class, 'show'])->name('orders.show');
    Route::post('/orders/{order}/shipping-address', [OrderController::class, 'updateShippingAddress'])->name('orders.updateShippingAddress');
    Route::post('/orders/{order}/cancel', [OrderController::class, 'cancel'])->name('orders.cancel');
    Route::match(['PUT', 'POST'], '/orders/{order}/status', [OrderController::class, 'updateStatus'])->name('orders.updateStatus');
    Route::post('/orders/{order}/release-payment', [OrderController::class, 'releasePayment'])->name('orders.releasePayment');
    Route::post('/orders/{order}/confirm-preparation', [OrderController::class, 'confirmPreparation'])->name('orders.confirmPreparation');
    Route::post('/orders/{order}/add-tracking', [OrderController::class, 'addTrackingNumber'])->name('orders.addTracking');
    Route::post('/orders/{order}/cancel-with-penalty', [OrderController::class, 'cancelWithPenalty'])->name('orders.cancelWithPenalty');
    
    // Checkout
    Route::get('/checkout/auction/{listing}', [CheckoutController::class, 'auctionCheckout'])->name('checkout.auction');
    Route::post('/checkout/auction/{listing}', [CheckoutController::class, 'processAuctionCheckout'])->name('checkout.auction.process');
    
    // Seller Reviews
    Route::get('/orders/{order}/review', [\App\Http\Controllers\SellerReviewController::class, 'create'])->name('seller-reviews.create');
    Route::post('/orders/{order}/review', [\App\Http\Controllers\SellerReviewController::class, 'store'])->name('seller-reviews.store');
    
    // Email Verification
    Route::post('/email/verify/send', [\App\Http\Controllers\Auth\EmailVerificationController::class, 'send'])->name('email.verify.send');
    Route::post('/email/verify', [\App\Http\Controllers\Auth\EmailVerificationController::class, 'verify'])->name('email.verify');

    // Phone Verification (AJAX)
    Route::post('/phone/verify/send', [\App\Http\Controllers\Auth\PhoneVerificationController::class, 'send'])->name('phone.verify.send');
    Route::post('/phone/verify', [\App\Http\Controllers\Auth\PhoneVerificationController::class, 'verify'])->name('phone.verify');

    // Tickets
    Route::get('/tickets', [\App\Http\Controllers\TicketController::class, 'index'])->name('tickets.index');
    Route::get('/tickets/create', [\App\Http\Controllers\TicketController::class, 'create'])->name('tickets.create');
    Route::post('/tickets', [\App\Http\Controllers\TicketController::class, 'store'])->name('tickets.store');
    Route::get('/tickets/{ticket}', [\App\Http\Controllers\TicketController::class, 'show'])->name('tickets.show');
    Route::post('/tickets/{ticket}/reply', [\App\Http\Controllers\TicketController::class, 'reply'])->name('tickets.reply');
    Route::post('/tickets/{ticket}/close', [\App\Http\Controllers\TicketController::class, 'close'])->name('tickets.close');

    // User Notifications (non-admin)
    Route::get('/notifications', [\App\Http\Controllers\NotificationController::class, 'index'])->name('user.notifications.index');
    Route::get('/notifications/recent', [\App\Http\Controllers\NotificationController::class, 'getRecent'])->name('user.notifications.recent');
    Route::get('/notifications/{id}/read', [\App\Http\Controllers\NotificationController::class, 'markAsRead'])->name('user.notifications.read');
    Route::post('/notifications/mark-all-read', [\App\Http\Controllers\NotificationController::class, 'markAllAsRead'])->name('user.notifications.mark-all-read');
    
    // Admin Routes
    Route::prefix('admin')->middleware('admin')->group(function () {
        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
        
        // Settings
        Route::get('/settings', [SettingsController::class, 'index'])->name('admin.settings.index');
        Route::put('/settings/deposit', [SettingsController::class, 'updateDeposit'])->name('admin.settings.deposit.update');
        Route::put('/settings/commission', [SettingsController::class, 'updateCommission'])->name('admin.settings.commission.update');
        Route::put('/settings/seller', [SettingsController::class, 'updateSeller'])->name('admin.settings.seller.update');
        Route::put('/settings/verification', [SettingsController::class, 'updateVerification'])->name('admin.settings.verification.update');
        Route::put('/settings/auction-duration', [SettingsController::class, 'updateAuctionDuration'])->name('admin.settings.auction-duration.update');
        Route::put('/settings/wallet', [SettingsController::class, 'updateWallet'])->name('admin.settings.wallet.update');
        Route::put('/settings/cancellation-penalty', [SettingsController::class, 'updateCancellationPenalty'])->name('admin.settings.cancellation-penalty.update');
        Route::put('/settings/test-period', [SettingsController::class, 'updateTestPeriod'])->name('admin.settings.test-period.update');
        Route::put('/settings/loser-fee', [SettingsController::class, 'updateLoserFee'])->name('admin.settings.loser-fee.update');
        Route::put('/settings/forfeit', [SettingsController::class, 'updateForfeit'])->name('admin.settings.forfeit.update');
        Route::put('/settings/auction-release', [SettingsController::class, 'updateAuctionRelease'])->name('admin.settings.auction-release.update');
        Route::put('/settings/listing', [SettingsController::class, 'updateListing'])->name('admin.settings.listing.update');
        Route::put('/settings/otp', [SettingsController::class, 'updateOtp'])->name('admin.settings.otp.update');
        Route::get('/settings/general', [SettingsController::class, 'general'])->name('admin.settings.general');
        Route::post('/settings/general', [SettingsController::class, 'updateGeneral'])->name('admin.settings.general.update');
        Route::post('/settings/general/upload-logo', [SettingsController::class, 'uploadLogo'])->name('admin.settings.general.upload-logo');

        // Payment Gateways
        Route::get('/payment-gateways', [\App\Http\Controllers\Admin\PaymentGatewayController::class, 'index'])->name('admin.payment-gateways.index');
        Route::get('/payment-gateways/{gateway}/edit', [\App\Http\Controllers\Admin\PaymentGatewayController::class, 'edit'])->name('admin.payment-gateways.edit');
        Route::put('/payment-gateways/{gateway}', [\App\Http\Controllers\Admin\PaymentGatewayController::class, 'update'])->name('admin.payment-gateways.update');
        Route::patch('/payment-gateways/{gateway}/toggle', [\App\Http\Controllers\Admin\PaymentGatewayController::class, 'toggle'])->name('admin.payment-gateways.toggle');

        // SMS Gateways
        Route::get('/sms-gateways', [\App\Http\Controllers\Admin\SmsGatewayController::class, 'index'])->name('admin.sms-gateways.index');
        Route::post('/sms-gateways', [\App\Http\Controllers\Admin\SmsGatewayController::class, 'save'])->name('admin.sms-gateways.save');
        Route::post('/sms-gateways/test', [\App\Http\Controllers\Admin\SmsGatewayController::class, 'test'])->name('admin.sms-gateways.test');

        // Category Commissions
        Route::get('/category-commissions', [\App\Http\Controllers\Admin\CategoryCommissionController::class, 'index'])->name('admin.category-commissions.index');
        Route::post('/category-commissions', [\App\Http\Controllers\Admin\CategoryCommissionController::class, 'store'])->name('admin.category-commissions.store');
        Route::delete('/category-commissions/{id}', [\App\Http\Controllers\Admin\CategoryCommissionController::class, 'destroy'])->name('admin.category-commissions.destroy');

        
        // Financial Reports
        Route::get('/financial-reports', [FinancialReportController::class, 'index'])->name('admin.financial-reports.index');
        Route::get('/financial-reports/commissions', [FinancialReportController::class, 'commissions'])->name('admin.financial-reports.commissions');
        Route::get('/financial-reports/export', [FinancialReportController::class, 'export'])->name('admin.financial-reports.export');
        Route::get('/financial-reports/chart-data', [FinancialReportController::class, 'chartData'])->name('admin.financial-reports.chart-data');
        
        // Categories
        Route::resource('categories', CategoryController::class, ['as' => 'admin']);
        Route::post('/categories/reorder', [CategoryController::class, 'reorder'])->name('admin.categories.reorder');
        
        // Category Attributes
        Route::get('/categories/{category}/attributes', [\App\Http\Controllers\Admin\CategoryAttributeController::class, 'index'])->name('admin.category-attributes.index');
        Route::get('/categories/{category}/attributes/create', [\App\Http\Controllers\Admin\CategoryAttributeController::class, 'create'])->name('admin.category-attributes.create');
        Route::post('/categories/{category}/attributes', [\App\Http\Controllers\Admin\CategoryAttributeController::class, 'store'])->name('admin.category-attributes.store');
        Route::get('/categories/{category}/attributes/{attribute}/edit', [\App\Http\Controllers\Admin\CategoryAttributeController::class, 'edit'])->name('admin.category-attributes.edit');
        Route::put('/categories/{category}/attributes/{attribute}', [\App\Http\Controllers\Admin\CategoryAttributeController::class, 'update'])->name('admin.category-attributes.update');
        Route::delete('/categories/{category}/attributes/{attribute}', [\App\Http\Controllers\Admin\CategoryAttributeController::class, 'destroy'])->name('admin.category-attributes.destroy');
        
        // Admin Listings Resource (using slug for SEO)
        Route::get('/listings', [AdminListingController::class, 'index'])->name('admin.listings.index');
        Route::get('/listings/export', [AdminListingController::class, 'export'])->name('admin.listings.export');
        Route::get('/listings/create', [AdminListingController::class, 'create'])->name('admin.listings.create');
        Route::post('/listings', [AdminListingController::class, 'store'])->name('admin.listings.store');
        Route::get('/listings/{listing}', [AdminListingController::class, 'show'])->name('admin.listings.show');
        Route::get('/listings/{listing}/edit', [AdminListingController::class, 'edit'])->name('admin.listings.edit');
        Route::put('/listings/{listing}', [AdminListingController::class, 'update'])->name('admin.listings.update');
        Route::delete('/listings/{listing}', [AdminListingController::class, 'destroy'])->name('admin.listings.destroy');
        
        // Auction Management Routes
        Route::get('/listings/{listing}/manage', [AdminListingController::class, 'manage'])->name('admin.listings.manage');
        Route::put('/listings/{listing}/settings', [AdminListingController::class, 'updateSettings'])->name('admin.listings.settings');
        Route::post('/listings/{listing}/end-early', [AdminListingController::class, 'endEarly'])->name('admin.listings.end-early');
        Route::post('/listings/{listing}/suspend', [AdminListingController::class, 'suspend'])->name('admin.listings.suspend');
        Route::post('/listings/{listing}/activate', [AdminListingController::class, 'activate'])->name('admin.listings.activate');
        Route::post('/listings/{listing}/approve', [AdminListingController::class, 'approve'])->name('admin.listings.approve');
        Route::post('/listings/{listing}/reject', [AdminListingController::class, 'reject'])->name('admin.listings.reject');
        Route::put('/listings/{listing}/tags', [AdminListingController::class, 'updateTags'])->name('admin.listings.tags');
        Route::get('/listings/{listing}/bids', [AdminListingController::class, 'getBids'])->name('admin.listings.bids');
        Route::post('/listings/{listing}/images', [AdminListingController::class, 'uploadImage'])->name('admin.listings.images.upload');
        Route::delete('/listings/{listing}/images/{image}', [AdminListingController::class, 'deleteImage'])->name('admin.listings.images.delete');
        Route::post('/listings/{listing}/images/{image}/set-main', [AdminListingController::class, 'setMainImage'])->name('admin.listings.images.set-main');
        
        // Pending Changes Management
        Route::post('/listings/{listing}/pending-changes/{change}/approve', [AdminListingController::class, 'approvePendingChanges'])->name('admin.listings.pending-changes.approve');
        Route::post('/listings/{listing}/pending-changes/{change}/reject', [AdminListingController::class, 'rejectPendingChanges'])->name('admin.listings.pending-changes.reject');
        
        // Bid Management
        Route::post('/bids/{bid}/cancel', [\App\Http\Controllers\Admin\BidController::class, 'cancel'])->name('admin.bids.cancel');
        
        // User Management
        Route::get('/users', [\App\Http\Controllers\Admin\UserController::class, 'index'])->name('admin.users.index');
        Route::get('/users/export', [\App\Http\Controllers\Admin\UserController::class, 'export'])->name('admin.users.export');
        Route::get('/users/{user}', [\App\Http\Controllers\Admin\UserController::class, 'show'])->name('admin.users.show');
        Route::post('/users/{user}/suspend', [\App\Http\Controllers\Admin\UserController::class, 'suspend'])->name('admin.users.suspend');
        Route::post('/users/{user}/activate', [\App\Http\Controllers\Admin\UserController::class, 'activate'])->name('admin.users.activate');
        Route::post('/users/{user}/verify-email', [\App\Http\Controllers\Admin\UserController::class, 'verifyEmail'])->name('admin.users.verify-email');
        Route::post('/users/{user}/adjust-wallet', [\App\Http\Controllers\Admin\UserController::class, 'adjustWallet'])->name('admin.users.adjustWallet');
        
        // Seller Management
        Route::get('/sellers', [\App\Http\Controllers\Admin\SellerController::class, 'index'])->name('admin.sellers.index');
        Route::get('/sellers/export', [\App\Http\Controllers\Admin\SellerController::class, 'export'])->name('admin.sellers.export');
        Route::get('/sellers/{seller}', [\App\Http\Controllers\Admin\SellerController::class, 'show'])->name('admin.sellers.show');
        Route::post('/sellers/{seller}/approve', [\App\Http\Controllers\Admin\SellerController::class, 'approve'])->name('admin.sellers.approve');
        Route::post('/sellers/{seller}/reject', [\App\Http\Controllers\Admin\SellerController::class, 'reject'])->name('admin.sellers.reject');
        Route::post('/sellers/{seller}/suspend', [\App\Http\Controllers\Admin\SellerController::class, 'suspend'])->name('admin.sellers.suspend');
        Route::post('/sellers/{seller}/activate', [\App\Http\Controllers\Admin\SellerController::class, 'activate'])->name('admin.sellers.activate');
        Route::delete('/sellers/{seller}', [\App\Http\Controllers\Admin\SellerController::class, 'destroy'])->name('admin.sellers.destroy');
        
        // Store Name Change Requests
        Route::get('/store-name-requests', [\App\Http\Controllers\Admin\SellerController::class, 'storeNameRequests'])->name('admin.store-name-requests.index');
        Route::post('/stores/{store}/approve-name', [\App\Http\Controllers\Admin\SellerController::class, 'approveStoreName'])->name('admin.stores.approve-name');
        Route::post('/stores/{store}/reject-name', [\App\Http\Controllers\Admin\SellerController::class, 'rejectStoreName'])->name('admin.stores.reject-name');
        
        // Tickets
        Route::get('/tickets', [\App\Http\Controllers\Admin\TicketController::class, 'index'])->name('admin.tickets.index');
        Route::get('/tickets/create', [\App\Http\Controllers\Admin\TicketController::class, 'create'])->name('admin.tickets.create');
        Route::post('/tickets', [\App\Http\Controllers\Admin\TicketController::class, 'store'])->name('admin.tickets.store');
        Route::get('/tickets/listings-for-user', [\App\Http\Controllers\Admin\TicketController::class, 'listingsForUser'])->name('admin.tickets.listings-for-user');
        Route::get('/tickets/{ticket}', [\App\Http\Controllers\Admin\TicketController::class, 'show'])->name('admin.tickets.show');
        Route::post('/tickets/{ticket}/reply', [\App\Http\Controllers\Admin\TicketController::class, 'reply'])->name('admin.tickets.reply');
        Route::post('/tickets/{ticket}/close', [\App\Http\Controllers\Admin\TicketController::class, 'close'])->name('admin.tickets.close');
        Route::post('/tickets/{ticket}/reopen', [\App\Http\Controllers\Admin\TicketController::class, 'reopen'])->name('admin.tickets.reopen');

        // Notifications
        Route::get('/notifications', [\App\Http\Controllers\Admin\NotificationController::class, 'index'])->name('admin.notifications.index');
        Route::get('/notifications/recent', [\App\Http\Controllers\Admin\NotificationController::class, 'getRecent'])->name('admin.notifications.recent');
        Route::get('/notifications/read/{id}', [\App\Http\Controllers\Admin\NotificationController::class, 'markAsRead'])->name('admin.notifications.read');
        Route::post('/notifications/mark-all-read', [\App\Http\Controllers\Admin\NotificationController::class, 'markAllAsRead'])->name('admin.notifications.mark-all-read');
        
        // Comments & Questions Management
        Route::get('/comments', [\App\Http\Controllers\Admin\CommentController::class, 'index'])->name('admin.comments.index');
        Route::post('/comments/{id}/approve', [\App\Http\Controllers\Admin\CommentController::class, 'approve'])->name('admin.comments.approve');
        Route::post('/comments/{id}/reject', [\App\Http\Controllers\Admin\CommentController::class, 'reject'])->name('admin.comments.reject');
        Route::delete('/comments/{id}', [\App\Http\Controllers\Admin\CommentController::class, 'destroy'])->name('admin.comments.destroy');
        
        // Seller Reviews Management
        Route::get('/seller-reviews', [\App\Http\Controllers\Admin\SellerReviewController::class, 'index'])->name('admin.seller-reviews.index');
        Route::post('/seller-reviews/{id}/approve', [\App\Http\Controllers\Admin\SellerReviewController::class, 'approve'])->name('admin.seller-reviews.approve');
        Route::post('/seller-reviews/{id}/reject', [\App\Http\Controllers\Admin\SellerReviewController::class, 'reject'])->name('admin.seller-reviews.reject');
        Route::delete('/seller-reviews/{id}', [\App\Http\Controllers\Admin\SellerReviewController::class, 'destroy'])->name('admin.seller-reviews.destroy');

        // Withdrawal Requests Management
        Route::get('/withdrawals', [\App\Http\Controllers\Admin\WithdrawalController::class, 'index'])->name('admin.withdrawals.index');
        Route::get('/withdrawals/export', [\App\Http\Controllers\Admin\WithdrawalController::class, 'export'])->name('admin.withdrawals.export');
        Route::post('/withdrawals/{withdrawal}/approve', [\App\Http\Controllers\Admin\WithdrawalController::class, 'approve'])->name('admin.withdrawals.approve');
        Route::post('/withdrawals/{withdrawal}/reject', [\App\Http\Controllers\Admin\WithdrawalController::class, 'reject'])->name('admin.withdrawals.reject');
        
        Route::resource('shipping-methods', ShippingMethodController::class, ['as' => 'admin']);
        
        // Order Management
        Route::get('/orders', [\App\Http\Controllers\Admin\OrderController::class, 'index'])->name('admin.orders.index');
        Route::get('/orders/export', [\App\Http\Controllers\Admin\OrderController::class, 'export'])->name('admin.orders.export');
        Route::get('/orders/{order}', [\App\Http\Controllers\Admin\OrderController::class, 'show'])->name('admin.orders.show');
        Route::put('/orders/{order}/status', [\App\Http\Controllers\Admin\OrderController::class, 'updateStatus'])->name('admin.orders.updateStatus');
        Route::put('/orders/{order}/shipping', [\App\Http\Controllers\Admin\OrderController::class, 'updateShipping'])->name('admin.orders.updateShipping');
        Route::post('/shipping-methods/{shippingMethod}/toggle', [ShippingMethodController::class, 'toggle'])->name('admin.shipping-methods.toggle');
        Route::resource('orders', AdminOrderController::class, ['as' => 'admin'])->only(['index', 'show']);

        // Homepage Builder
        Route::get('/homepage', [\App\Http\Controllers\Admin\HomepageController::class, 'index'])->name('admin.homepage.index');
        Route::post('/homepage/blocks', [\App\Http\Controllers\Admin\HomepageController::class, 'saveBlocks'])->name('admin.homepage.blocks.save');
        Route::post('/homepage/blocks/add', [\App\Http\Controllers\Admin\HomepageController::class, 'addBlock'])->name('admin.homepage.blocks.add');
        Route::delete('/homepage/blocks/{blockId}', [\App\Http\Controllers\Admin\HomepageController::class, 'deleteBlock'])->name('admin.homepage.blocks.delete');
        Route::post('/homepage/blocks/{blockId}', [\App\Http\Controllers\Admin\HomepageController::class, 'updateBlock'])->name('admin.homepage.blocks.update');
        Route::post('/homepage/blocks/{blockId}/upload', [\App\Http\Controllers\Admin\HomepageController::class, 'uploadBlockImage'])->name('admin.homepage.blocks.upload');
        Route::post('/homepage/card-style', [\App\Http\Controllers\Admin\HomepageController::class, 'updateCardStyle'])->name('admin.homepage.card-style');

        // Newsletter
        Route::get('/newsletter', [\App\Http\Controllers\Admin\NewsletterController::class, 'index'])->name('admin.newsletter.index');
        Route::get('/newsletter/export', [\App\Http\Controllers\Admin\NewsletterController::class, 'export'])->name('admin.newsletter.export');
        Route::delete('/newsletter/{subscriber}', [\App\Http\Controllers\Admin\NewsletterController::class, 'destroy'])->name('admin.newsletter.destroy');
        Route::post('/newsletter/{subscriber}/toggle', [\App\Http\Controllers\Admin\NewsletterController::class, 'toggleStatus'])->name('admin.newsletter.toggle');
        Route::post('/newsletter/send', [\App\Http\Controllers\Admin\NewsletterController::class, 'sendEmail'])->name('admin.newsletter.send');

        // Theme / Header & Footer
        Route::get('/theme', [\App\Http\Controllers\Admin\ThemeController::class, 'index'])->name('admin.theme.index');
        Route::post('/theme', [\App\Http\Controllers\Admin\ThemeController::class, 'save'])->name('admin.theme.save');

        // Pages Manager
        Route::resource('pages', \App\Http\Controllers\Admin\PageController::class, ['as' => 'admin']);
        Route::post('/pages/upload-image', [\App\Http\Controllers\Admin\PageController::class, 'uploadImage'])->name('admin.pages.upload-image');

        // Notification Settings
        Route::get('/notification-settings', [\App\Http\Controllers\Admin\NotificationSettingController::class, 'index'])->name('admin.notification-settings.index');
        Route::put('/notification-settings', [\App\Http\Controllers\Admin\NotificationSettingController::class, 'update'])->name('admin.notification-settings.update');
        Route::put('/notification-settings/admin-phone', [\App\Http\Controllers\Admin\NotificationSettingController::class, 'updateAdminPhone'])->name('admin.notification-settings.update-admin-phone');
        Route::post('/notification-settings/{setting}/test', [\App\Http\Controllers\Admin\NotificationSettingController::class, 'test'])->name('admin.notification-settings.test');
        Route::post('/notification-settings/{setting}/test-email', [\App\Http\Controllers\Admin\NotificationSettingController::class, 'testEmail'])->name('admin.notification-settings.test-email');

        // Update System
        Route::get('/update', [\App\Http\Controllers\Admin\UpdateController::class, 'index'])->name('admin.update.index');
        Route::post('/update/run', [\App\Http\Controllers\Admin\UpdateController::class, 'run'])->name('admin.update.run');
    });
});

// Public pages
Route::get('/page/{slug}', [\App\Http\Controllers\PageController::class, 'show'])->name('pages.show');

// Newsletter public routes
Route::post('/newsletter/subscribe', [\App\Http\Controllers\NewsletterController::class, 'subscribe'])->name('newsletter.subscribe');
Route::get('/newsletter/unsubscribe/{token}', [\App\Http\Controllers\NewsletterController::class, 'unsubscribe'])->name('newsletter.unsubscribe');
